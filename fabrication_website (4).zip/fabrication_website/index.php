<link rel="stylesheet" href="css/style1.css">

<div class="home-container">
    <img src="home.jpg" alt="Sai Fabrication Banner" class="home-image">
    
    <h1>Welcome to Sai Fabrication</h1>
    
    <div class="button-group">
        <a href="register.php" class="btn">Register</a>
        <a href="login.php" class="btn">Login</a>
    </div>
</div>
