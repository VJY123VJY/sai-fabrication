


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>About Us - sai Fabrication</title>
    <link rel="stylesheet" href="css/style4.css"> <!-- Link your CSS -->
   
</head>
<body>
    <div class="container mt-5">
        <h1 class="mb-4">About Us</h1>
        <p>
            <strong>Sairam Fabrication</strong> is a leading provider of high-quality metal fabrication services.
            With over 10 years of industry experience, we specialize in welding, laser cutting, and custom metal structures.
        </p>

        <h3 class="mt-4">Our Mission</h3>
        <p>
            Our mission is to deliver precision, durability, and innovation in every project we handle.
            We aim to exceed client expectations through skilled craftsmanship and reliable service.
        </p>

        <h3 class="mt-4">Our Team</h3>
        <p>
            Our team consists of experienced engineers, certified welders, and creative designers who work
            together to bring your vision to life. We are committed to safety, quality, and timely delivery.
        </p>

        <h3 class="mt-4">Why Choose Us?</h3>
        <ul>
            <li>✔ State-of-the-art equipment</li>
            <li>✔ Skilled and certified workforce</li>
            <li>✔ Timely project delivery</li>
            <li>✔ Competitive pricing</li>
            <li>✔ Custom solutions for every client</li>
        </ul>

        <a href="index.php" class="btn btn-primary mt-4">Back to Home</a>
    </div>
</body>
</html>
