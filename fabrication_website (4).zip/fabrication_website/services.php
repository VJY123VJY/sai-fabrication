<link rel="stylesheet" href="css/style5.css">

<section class="services-section">
    <h2>Our Services</h2>
    <div class="services-container">
        <div class="service-card">
            <h3>🛠️ Metal Fabrication</h3>
            <p>Precision cutting, forming, and assembling of metal structures tailored to your needs.</p>
        </div>
        <div class="service-card">
            <h3>🔥 Welding</h3>
            <p>Expert welding services ensuring strong and durable joints using advanced techniques.</p>
        </div>
        <div class="service-card">
            <h3>
